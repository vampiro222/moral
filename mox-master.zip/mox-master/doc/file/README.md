## `./tests/fixtures/functionSomeClass.js`
* [`SomeClass`][0]
* [`aProperty`][1]
* [`aPropertyWithType`][2]
* [`someClassMethod`][3]
* [`SomeClass2`][4]
* [`someClassMethod2`][5]

## `./tests/fixtures/functionSomeClass.js`

### `SomeClass`

[\#][0] | [Ⓣ][6]



Example:

    SomeClass.someClassMethod(x);

#### Arguments
1. `param` (*String*) - a parameter

---



### `aProperty`

[\#][1] | [Ⓣ][6]



Some property description

---



### `aPropertyWithType`

[\#][2] | [Ⓣ][6]

#### Types




Some property with type description

---



### `someClassMethod`

[\#][3] | [Ⓣ][6]



Example:

    SomeClass.someClassMethod(x);

#### Arguments
1. `methodParam` (*Function | String*) - some method param

#### Returns  
  
*(Function | String)* - A return value

---



### `SomeClass2`

[\#][4] | [Ⓣ][6]



Example:

    SomeClass2.someClassMethod(x);

#### Arguments
1. `param` (*String*) - a parameter

---



### `someClassMethod2`

[\#][5] | [Ⓣ][6]



Example:

    SomeClass2.someClassMethod(x);

#### Arguments
1. `methodParam` (*Function*) - some method param
2. `methodParam2` (*Function*) - some method param

#### Returns  
  
*(String)* - A return value

---


[0]: #someclass
[1]: #aproperty
[2]: #apropertywithtype
[3]: #someclassmethod
[4]: #someclass2
[5]: #someclassmethod2
[6]: #./tests/fixtures/functionsomeclass.js